<script type="text/javascript">
jQuery(document).ready(function($){
$('select[name^="item_meta"], textarea[name^="item_meta"]').css('float','left');
$('input[name^="item_meta"]').not(':radio, :checkbox').css('float','left');
});
</script>