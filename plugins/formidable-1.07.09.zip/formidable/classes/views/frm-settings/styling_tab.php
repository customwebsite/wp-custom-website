<div class="frm_update_msg">
This plugin version does not give you access to the visual form styler.<br/>
<a href="http://formidablepro.com/pricing/" target="_blank">Compare</a> our plans to find a solution that's right for you.
</div>