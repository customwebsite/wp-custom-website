=== Custom Footer Replacer ===  
Contributors: Shaun Haddrill
Tags: Custom Website
Requires at least: 3.0.0
Tested up to: 3.3.1
Stable tag: 1.7

== Description ==
Custom Footer Replacer is a plugin developer by the Custom Website team to add features to a wordpress website which are commonly asked for such as removal of wordpress and theme author credits.

== Changelog ==

=1.1=
* Feature: Initial release with admin bar at bottom
=1.2=
* Improvement: Added PR Checker functionality, if PR < 1 then do not provide link to Custom Website
=1.3=
* Feature: Replace logo on login page from Wordpress to Custom Website logo
* Improvement: Replaced the icon image linked to PR > 0 websites used in the admin bar with a php based image which is used for statisical analysis of user behavior
=1.4=
* Improvement: Replaced the icon image linked to PR < 1 websites used in the admin bar with a php based image which is used for statisical analysis of user behavior
=1.5=
* Improvement: Added display none CSS style for two more common ID's used in the footer of themes, #copyright and #site-generator
* Improvement: Changed "Designed by Custom Website" text to "Powered by Custom Website" text in footer
=1.6=
* Bug: Added javascript hack for iOS safari browsers to display the footer at the bottom of the page, previously it was floating in the middle or top of page, this may not be a perfect fix because the width is still limited by screen size and does not adjust with zooming.
=1.7=
* Feature: Added the removal of website field using CSS in user profile page to prevent spammers adding website urls to post, this may not stop spam bots..
* Bug: Changed z-index to 999 999 for footer to not hide the zopimg chat widget which is set at 10 000 000