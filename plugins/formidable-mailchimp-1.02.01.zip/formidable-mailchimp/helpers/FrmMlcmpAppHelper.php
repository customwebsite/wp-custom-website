<?php
 
class FrmMlcmpAppHelper{
    
    public static function get_default_options(){
        return array(
            'mailchimp' => 0, 
            'mlcmp_list' => array()
        );
    }
    
}